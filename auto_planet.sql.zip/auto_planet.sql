-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 30, 2013 at 03:21 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `auto_planet`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE IF NOT EXISTS `bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobsheet_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `bill_date` datetime NOT NULL,
  `billing_address` text CHARACTER SET latin1 NOT NULL,
  `billing_contact` varchar(100) CHARACTER SET latin1 NOT NULL,
  `payment_mode` varchar(100) CHARACTER SET latin1 NOT NULL,
  `reg_no` varchar(100) DEFAULT NULL,
  `chassis_no` varchar(200) DEFAULT NULL,
  `round_off` decimal(10,4) DEFAULT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bill`
--


-- --------------------------------------------------------

--
-- Table structure for table `bill_charges`
--

CREATE TABLE IF NOT EXISTS `bill_charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) NOT NULL,
  `job_description` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bill_charges`
--


-- --------------------------------------------------------

--
-- Table structure for table `bill_parts`
--

CREATE TABLE IF NOT EXISTS `bill_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) NOT NULL,
  `part_name` text NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bill_parts`
--


-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purpose` varchar(200) CHARACTER SET latin1 NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_on` date NOT NULL,
  `bill_no` varchar(50) CHARACTER SET latin1 NOT NULL,
  `notes` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=153 ;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `purpose`, `amount`, `created_on`, `bill_no`, `notes`) VALUES
(1, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(2, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(3, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(4, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(5, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(6, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(7, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(8, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(9, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(10, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(11, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(12, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(13, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(14, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(15, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(16, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(17, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(18, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(19, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(20, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(21, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(22, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(23, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(24, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(25, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(26, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(27, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(28, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(29, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(30, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(31, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(32, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(33, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(34, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(35, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(36, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(37, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(38, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(39, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(40, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(41, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(42, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(43, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(44, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(45, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(46, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(47, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(48, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(49, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(50, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(51, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(52, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(53, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(54, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(55, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(56, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(57, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(58, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(59, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(60, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(61, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(62, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(63, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(64, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(65, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(66, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(67, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(68, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(69, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(70, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(71, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(72, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(73, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(74, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(75, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(76, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(77, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(78, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(79, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(80, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(81, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(82, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(83, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(84, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(85, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(86, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(87, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(88, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(89, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(90, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(91, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(92, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(93, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(94, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(95, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(96, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(97, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(98, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(99, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(100, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(101, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(102, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(103, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(104, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(105, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(106, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(107, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(108, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(109, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(110, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(111, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(112, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(113, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(114, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(115, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(116, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(117, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(118, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(119, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(120, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(121, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(122, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(123, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(124, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(125, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(126, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(127, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(128, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(129, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(130, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(131, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(132, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(133, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(134, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(135, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(136, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(137, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(138, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(139, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(140, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(141, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(142, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(143, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(144, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(145, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Current bill for May 2013. This also can be a lot more expensive. It includes advance payment for 2014 as well.'),
(146, 'Electricity Bill', '1750.00', '2013-08-05', '74358', 'Sample notes.'),
(147, 'Electricity Bill2', '1750.00', '2013-08-05', '74358', 'Sample notes2.'),
(148, 'Electricity Bill3', '1750.00', '2013-08-05', '74358', 'Sample notes3.'),
(149, 'Electricity Bill4', '1750.00', '2013-08-05', '74358', 'Sample notes4.'),
(150, 'Electricity Bill5', '1750.00', '2013-08-05', '74358', 'Sample notes5.'),
(151, 'Petrol filling', '550.45', '2013-08-23', '23123', 'kjyguy'),
(152, 'ascascasc', '10000.00', '2013-08-25', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jobsheets`
--

CREATE TABLE IF NOT EXISTS `jobsheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET latin1 NOT NULL,
  `address` text CHARACTER SET latin1 NOT NULL,
  `contact` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `reg_no` varchar(50) NOT NULL,
  `mileage` decimal(10,2) NOT NULL,
  `chassis_no` varchar(100) CHARACTER SET latin1 NOT NULL,
  `engine_no` varchar(100) CHARACTER SET latin1 NOT NULL,
  `promised_date` datetime NOT NULL,
  `estimated_amount` decimal(10,2) NOT NULL,
  `works_done` text CHARACTER SET latin1 NOT NULL,
  `status` varchar(20) CHARACTER SET latin1 NOT NULL,
  `notes` text CHARACTER SET latin1 NOT NULL,
  `delivered_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1116 ;

--
-- Dumping data for table `jobsheets`
--

INSERT INTO `jobsheets` (`id`, `name`, `address`, `contact`, `created_on`, `reg_no`, `mileage`, `chassis_no`, `engine_no`, `promised_date`, `estimated_amount`, `works_done`, `status`, `notes`, `delivered_date`) VALUES
(116, 'uuuuuuuuuuu', '', '99999999', '2013-08-29 00:00:00', 'sdsf-dfsf', '123123.00', '', '', '2013-08-09 00:00:00', '0.00', '', 'complete', '', '2013-08-31'),
(1001, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1002, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1005, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1007, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1008, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1009, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1012, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1013, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1014, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1015, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '2013-08-22 00:00:00', 'KL-10-A-1234', '13467.91', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', 'complete', 'Special notes for the needy kind. Kooool\r\n', '2013-08-22'),
(1016, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1017, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1018, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1019, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1020, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1021, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1022, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1023, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1024, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1025, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1026, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1027, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1028, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1029, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1030, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1031, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1032, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1033, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1034, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1035, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1036, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1037, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1038, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', 'complete', '', '2013-08-29'),
(1039, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1040, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1041, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1042, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1043, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1044, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1045, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1046, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1047, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1048, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1049, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1050, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1051, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1052, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1053, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1054, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1055, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1056, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', 'close', '', NULL),
(1057, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1058, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1059, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1060, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1061, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1062, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1063, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1064, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1065, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1066, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1067, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1068, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1069, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1070, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1071, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1072, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1073, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1074, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1075, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1076, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1077, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1078, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1079, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1080, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1081, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1082, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1083, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1084, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1085, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1086, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1087, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1088, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1089, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1090, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1091, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1092, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1093, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1094, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1095, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1096, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1097, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1098, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1099, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1100, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1101, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1102, 'Jobsheet1', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 14:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1103, 'Jobsheet2', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 13:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'Open', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1104, 'Jobsheet5', 'Angadippuram,\r\nMalappram,\r\nKerala - 679321', '8547257874', '2013-07-28 15:14:05', 'KL-53-E-656', '6800.00', '464546546544646', '6576577886878', '2013-07-30 15:14:05', '1500.00', '- Body Paint\r\n- Dent Removal\r\n- Washing', 'reopen', 'This is a special notes area wherein you can enter whatever you want.', NULL),
(1105, 'Shafi', 'This is my address,\r\nasdasd,\r\nasdas - 787', '9846100100', '1970-01-01 00:00:00', 'KL-10-A-1234', '13467.90', '21312eqd12312', 'asdasd123213ada', '1970-01-01 00:00:00', '1500.56', 'asdasd\r\nasdasd\r\nasdasdasdasdasd\r\nasd dasdasd', '0', 'Special notes for the needy kind.', NULL),
(1106, 'fwefwef', 'nkn', '7979799', '2013-01-08 00:00:00', 'saasd-asd', '12312.00', '', '', '1970-01-01 00:00:00', '0.00', '', '0', '', NULL),
(1107, 'sfsdf', '', '1231231', '2013-01-08 00:00:00', 'qwe-qwe', '123123.00', '', '', '2013-08-16 00:00:00', '0.00', '', '0', '', NULL),
(1108, 'NewEdit', '', '89898989111', '2013-07-30 00:00:00', 'dasd-asd', '9999.12', '', '', '2013-08-30 00:00:00', '759.78', '', 'reopen', '', NULL),
(1109, 'fsfsdf', '', '879879', '2013-08-05 00:00:00', 'iuyuyiuy', '888.00', '', '', '2013-08-02 00:00:00', '0.00', '', '0', '', NULL),
(1110, 'scsdcsd', '', '765656', '2013-08-05 00:00:00', 'sfsdfsdf', '34234.00', '', '', '2013-08-01 00:00:00', '0.00', '', '0', '', NULL),
(1111, 'yyyy', '', '678687687', '2013-08-22 00:00:00', 'vgh-7656f', '7676.00', '', '', '2013-08-24 00:00:00', '0.00', '', '0', '', NULL),
(1113, 'wwerwer', '', '565123123', '2013-08-22 00:00:00', 'yu7-yu', '6776.00', '', '', '2013-08-09 00:00:00', '0.00', '', '0', '', NULL),
(1114, 'jhjh', '', '67676767', '2013-08-23 00:00:00', 'kjjh-9898', '656565.00', '', '', '2013-08-10 00:00:00', '0.00', '', 'complete', 'Yahoo! News is an Internet-based news aggregator by Yahoo!. It categorizes news into "Top Stories", "U.S. National", "World", "Business", "Entertainment", "Science", "Health", "Weather", "Most Popular", "News Photos", "Op/Ed", and "Local News".\r\n\r\nArticles in Yahoo! News come from news services, such as Associated Press, Reuters, Agence France-Presse, Fox News, ABC News, NPR, USA Today, CNN.com, CBC News, Seven News, and BBC News.\r\n\r\nIn 2001 Yahoo! News launched the first "most-emailed" page on the web.[2] The idea was created and implemented by Yahoo! software engineer Tony Tam.[3]\r\n\r\nYahoo! allowed comments for news articles until December 19, 2006, when commentary was disabled. Comments were re-enabled on March 2, 2010.[4] Comments were temporarily disabled between December 10, 2011, and December 15, 2011, due to glitches.[citation needed]', '2013-09-01'),
(1115, 'iuihi', '', '11111111', '2013-08-27 00:00:00', '111111', '56565.00', '303030', '', '2013-08-23 00:00:00', '0.00', '', 'complete', '', '2013-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `jobsheet_charges`
--

CREATE TABLE IF NOT EXISTS `jobsheet_charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobsheet_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `job_type` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `jobsheet_charges`
--

INSERT INTO `jobsheet_charges` (`id`, `jobsheet_id`, `staff`, `job_type`, `amount`, `description`) VALUES
(7, 112, 2, 1, '6767.00', NULL),
(8, 112, 4, 1, '7878.00', NULL),
(10, 113, 2, 1, '123123.00', NULL),
(11, 113, 1, 1, '12312.00', NULL),
(53, 114, 1, 1, '900.00', NULL),
(54, 114, 2, 3, '5000.00', NULL),
(55, 15, 2, 3, '1500.00', NULL),
(56, 15, 1, 1, '500.00', NULL),
(87, 111, 2, 2, '300.00', NULL),
(88, 111, 1, 4, '200.00', NULL),
(91, 1092, 2, 1, '5000.00', 'Changed gear shaft and some livers for that livers for that livers for that livers for that livers f'),
(92, 116, 2, 2, '9999.00', 'fwefwefwe we fwefwe fwefwefwef wef wefwe');

-- --------------------------------------------------------

--
-- Table structure for table `jobsheet_parts`
--

CREATE TABLE IF NOT EXISTS `jobsheet_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobsheet_id` int(11) NOT NULL,
  `part_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `jobsheet_parts`
--

INSERT INTO `jobsheet_parts` (`id`, `jobsheet_id`, `part_id`, `qty`) VALUES
(32, 114, 1003, 5),
(33, 114, 1004, 21),
(34, 15, 1003, 10),
(35, 116, 1017, 0);

-- --------------------------------------------------------

--
-- Table structure for table `job_types`
--

CREATE TABLE IF NOT EXISTS `job_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `job_types`
--

INSERT INTO `job_types` (`id`, `type`) VALUES
(1, 'Mechanical'),
(2, 'Dent Removal'),
(3, 'Painting'),
(4, 'Polishing'),
(6, 'Electrical');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 NOT NULL,
  `password` varchar(200) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'autoplanet', '6a3684e5ffe98ea04a5f877ef0f163dd'),
(2, 'admin', '4fa514e99e7e1ded1442f9e8741c8b46');

-- --------------------------------------------------------

--
-- Table structure for table `parts`
--

CREATE TABLE IF NOT EXISTS `parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `mrp` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1750 ;

--
-- Dumping data for table `parts`
--

INSERT INTO `parts` (`id`, `name`, `dealer_price`, `mrp`, `description`) VALUES
(1003, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1004, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1005, 'yyutyu', '6565.00', '54654.00', ''),
(1007, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1008, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1009, 'yyutyu', '6565.00', '54654.00', ''),
(1013, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1014, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1015, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1016, 'yyutyu', '6565.00', '54654.00', ''),
(1017, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1018, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1019, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1020, 'yyutyu', '6565.00', '54654.00', ''),
(1028, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1029, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1030, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1031, 'yyutyu', '6565.00', '54654.00', ''),
(1032, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1033, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1034, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1035, 'yyutyu', '6565.00', '54654.00', ''),
(1036, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1037, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1038, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1039, 'yyutyu', '6565.00', '54654.00', ''),
(1040, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1041, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1042, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1043, 'yyutyu', '6565.00', '54654.00', ''),
(1059, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1060, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1061, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1062, 'yyutyu', '6565.00', '54654.00', ''),
(1063, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1064, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1065, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1066, 'yyutyu', '6565.00', '54654.00', ''),
(1067, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1068, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1069, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1070, 'yyutyu', '6565.00', '54654.00', ''),
(1071, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1072, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1073, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1074, 'yyutyu', '6565.00', '54654.00', ''),
(1075, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1076, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1077, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1078, 'yyutyu', '6565.00', '54654.00', ''),
(1079, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1080, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1081, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1082, 'yyutyu', '6565.00', '54654.00', ''),
(1083, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1084, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1085, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1086, 'yyutyu', '6565.00', '54654.00', ''),
(1087, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1088, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1089, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1090, 'yyutyu', '6565.00', '54654.00', ''),
(1122, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1123, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1124, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1125, 'yyutyu', '6565.00', '54654.00', ''),
(1126, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1127, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1128, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1129, 'yyutyu', '6565.00', '54654.00', ''),
(1130, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1131, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1132, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1133, 'yyutyu', '6565.00', '54654.00', ''),
(1134, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1135, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1136, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1137, 'yyutyu', '6565.00', '54654.00', ''),
(1138, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1139, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1140, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1141, 'yyutyu', '6565.00', '54654.00', ''),
(1142, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1143, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1144, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1145, 'yyutyu', '6565.00', '54654.00', ''),
(1146, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1147, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1148, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1149, 'yyutyu', '6565.00', '54654.00', ''),
(1150, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1151, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1152, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1153, 'yyutyu', '6565.00', '54654.00', ''),
(1154, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1155, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1156, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1157, 'yyutyu', '6565.00', '54654.00', ''),
(1158, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1159, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1160, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1161, 'yyutyu', '6565.00', '54654.00', ''),
(1162, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1163, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1164, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1165, 'yyutyu', '6565.00', '54654.00', ''),
(1166, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1167, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1168, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1169, 'yyutyu', '6565.00', '54654.00', ''),
(1170, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1171, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1172, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1173, 'yyutyu', '6565.00', '54654.00', ''),
(1174, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1175, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1176, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1177, 'yyutyu', '6565.00', '54654.00', ''),
(1178, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1179, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1180, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1181, 'yyutyu', '6565.00', '54654.00', ''),
(1182, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1183, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1184, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1185, 'yyutyu', '6565.00', '54654.00', ''),
(1249, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1250, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1251, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1252, 'yyutyu', '6565.00', '54654.00', ''),
(1253, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1254, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1255, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1256, 'yyutyu', '6565.00', '54654.00', ''),
(1257, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1258, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1259, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1260, 'yyutyu', '6565.00', '54654.00', ''),
(1261, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1262, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1263, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1264, 'yyutyu', '6565.00', '54654.00', ''),
(1265, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1266, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1267, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1268, 'yyutyu', '6565.00', '54654.00', ''),
(1269, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1270, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1271, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1272, 'yyutyu', '6565.00', '54654.00', ''),
(1273, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1274, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1275, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1276, 'yyutyu', '6565.00', '54654.00', ''),
(1277, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1278, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1279, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1280, 'yyutyu', '6565.00', '54654.00', ''),
(1281, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1282, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1283, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1284, 'yyutyu', '6565.00', '54654.00', ''),
(1285, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1286, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1287, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1288, 'yyutyu', '6565.00', '54654.00', ''),
(1289, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1290, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1291, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1292, 'yyutyu', '6565.00', '54654.00', ''),
(1293, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1294, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1295, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1296, 'yyutyu', '6565.00', '54654.00', ''),
(1297, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1298, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1299, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1300, 'yyutyu', '6565.00', '54654.00', ''),
(1301, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1302, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1303, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1304, 'yyutyu', '6565.00', '54654.00', ''),
(1305, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1306, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1307, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1308, 'yyutyu', '6565.00', '54654.00', ''),
(1309, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1310, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1311, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1312, 'yyutyu', '6565.00', '54654.00', ''),
(1313, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1314, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1315, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1316, 'yyutyu', '6565.00', '54654.00', ''),
(1317, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1318, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1319, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1320, 'yyutyu', '6565.00', '54654.00', ''),
(1321, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1322, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1323, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1324, 'yyutyu', '6565.00', '54654.00', ''),
(1325, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1326, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1327, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1328, 'yyutyu', '6565.00', '54654.00', ''),
(1329, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1330, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1331, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1332, 'yyutyu', '6565.00', '54654.00', ''),
(1333, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1334, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1335, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1336, 'yyutyu', '6565.00', '54654.00', ''),
(1337, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1338, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1339, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1340, 'yyutyu', '6565.00', '54654.00', ''),
(1341, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1342, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1343, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1344, 'yyutyu', '6565.00', '54654.00', ''),
(1345, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1346, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1347, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1348, 'yyutyu', '6565.00', '54654.00', ''),
(1349, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1350, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1351, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1352, 'yyutyu', '6565.00', '54654.00', ''),
(1353, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1354, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1355, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1356, 'yyutyu', '6565.00', '54654.00', ''),
(1357, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1358, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1359, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1360, 'yyutyu', '6565.00', '54654.00', ''),
(1361, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1362, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1363, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1364, 'yyutyu', '6565.00', '54654.00', ''),
(1365, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1366, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1367, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1368, 'yyutyu', '6565.00', '54654.00', ''),
(1369, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1370, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1371, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1372, 'yyutyu', '6565.00', '54654.00', ''),
(1373, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1374, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1375, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1376, 'yyutyu', '6565.00', '54654.00', ''),
(1504, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1505, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1506, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1507, 'yyutyu', '6565.00', '54654.00', ''),
(1508, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1509, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1510, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1511, 'yyutyu', '6565.00', '54654.00', ''),
(1512, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1513, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1514, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1515, 'yyutyu', '6565.00', '54654.00', ''),
(1516, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1517, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1518, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1519, 'yyutyu', '6565.00', '54654.00', ''),
(1520, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1521, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1522, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1523, 'yyutyu', '6565.00', '54654.00', ''),
(1524, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1525, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1526, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1527, 'yyutyu', '6565.00', '54654.00', ''),
(1528, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1529, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1530, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1531, 'yyutyu', '6565.00', '54654.00', ''),
(1532, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1533, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1534, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1535, 'yyutyu', '6565.00', '54654.00', ''),
(1536, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1537, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1538, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1539, 'yyutyu', '6565.00', '54654.00', ''),
(1540, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1541, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1542, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1543, 'yyutyu', '6565.00', '54654.00', ''),
(1544, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1545, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1546, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1547, 'yyutyu', '6565.00', '54654.00', ''),
(1548, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1549, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1550, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1551, 'yyutyu', '6565.00', '54654.00', ''),
(1552, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1553, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1554, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1555, 'yyutyu', '6565.00', '54654.00', ''),
(1556, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1557, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1558, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1559, 'yyutyu', '6565.00', '54654.00', ''),
(1560, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1561, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1562, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1563, 'yyutyu', '6565.00', '54654.00', ''),
(1564, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1565, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1566, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1567, 'yyutyu', '6565.00', '54654.00', ''),
(1568, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1569, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1570, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1571, 'yyutyu', '6565.00', '54654.00', ''),
(1572, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1573, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1574, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1575, 'yyutyu', '6565.00', '54654.00', ''),
(1576, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1577, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1578, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1579, 'yyutyu', '6565.00', '54654.00', ''),
(1580, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1581, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1582, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1583, 'yyutyu', '6565.00', '54654.00', ''),
(1584, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1585, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1586, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1587, 'yyutyu', '6565.00', '54654.00', ''),
(1588, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1589, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1590, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1591, 'yyutyu', '6565.00', '54654.00', ''),
(1592, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1593, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1594, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1595, 'yyutyu', '6565.00', '54654.00', ''),
(1596, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1597, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1598, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1599, 'yyutyu', '6565.00', '54654.00', ''),
(1600, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1601, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1602, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1603, 'yyutyu', '6565.00', '54654.00', ''),
(1604, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1605, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1606, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1607, 'yyutyu', '6565.00', '54654.00', ''),
(1608, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1609, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1610, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1611, 'yyutyu', '6565.00', '54654.00', ''),
(1612, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1613, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1614, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1615, 'yyutyu', '6565.00', '54654.00', ''),
(1616, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1617, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1618, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1619, 'yyutyu', '6565.00', '54654.00', ''),
(1620, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1621, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1622, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1623, 'yyutyu', '6565.00', '54654.00', ''),
(1624, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1625, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1626, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1627, 'yyutyu', '6565.00', '54654.00', ''),
(1628, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1629, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1630, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1631, 'yyutyu', '6565.00', '54654.00', ''),
(1632, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1633, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1634, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1635, 'yyutyu', '6565.00', '54654.00', ''),
(1636, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1637, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1638, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1639, 'yyutyu', '6565.00', '54654.00', ''),
(1640, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1641, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1642, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1643, 'yyutyu', '6565.00', '54654.00', ''),
(1644, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1645, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1646, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1647, 'yyutyu', '6565.00', '54654.00', ''),
(1648, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1649, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1650, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1651, 'yyutyu', '6565.00', '54654.00', ''),
(1652, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1653, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1654, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1655, 'yyutyu', '6565.00', '54654.00', ''),
(1656, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1657, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1658, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1659, 'yyutyu', '6565.00', '54654.00', ''),
(1660, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1661, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1662, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1663, 'yyutyu', '6565.00', '54654.00', ''),
(1664, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1665, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1666, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1667, 'yyutyu', '6565.00', '54654.00', ''),
(1668, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1669, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1670, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1671, 'yyutyu', '6565.00', '54654.00', ''),
(1672, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1673, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1674, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1675, 'yyutyu', '6565.00', '54654.00', ''),
(1676, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1677, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1678, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1679, 'yyutyu', '6565.00', '54654.00', ''),
(1680, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1681, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1682, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1683, 'yyutyu', '6565.00', '54654.00', ''),
(1684, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1685, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1686, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1687, 'yyutyu', '6565.00', '54654.00', ''),
(1688, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1689, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1690, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1691, 'yyutyu', '6565.00', '54654.00', ''),
(1692, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1693, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1694, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1695, 'yyutyu', '6565.00', '54654.00', ''),
(1696, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1697, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1698, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1699, 'yyutyu', '6565.00', '54654.00', ''),
(1700, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1701, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1702, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1703, 'yyutyu', '6565.00', '54654.00', ''),
(1704, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1705, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1706, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1707, 'yyutyu', '6565.00', '54654.00', ''),
(1708, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1709, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1710, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1711, 'yyutyu', '6565.00', '54654.00', ''),
(1712, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1713, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1714, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1715, 'yyutyu', '6565.00', '54654.00', ''),
(1716, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1717, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1718, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1719, 'yyutyu', '6565.00', '54654.00', ''),
(1720, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1721, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1722, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1723, 'yyutyu', '6565.00', '54654.00', ''),
(1724, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1725, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1726, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1727, 'yyutyu', '6565.00', '54654.00', ''),
(1728, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1729, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1730, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1731, 'yyutyu', '6565.00', '54654.00', ''),
(1732, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1733, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1734, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1735, 'yyutyu', '6565.00', '54654.00', ''),
(1736, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1737, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1738, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1739, 'yyutyu', '6565.00', '54654.00', ''),
(1740, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1741, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1742, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1743, 'yyutyu', '6565.00', '54654.00', ''),
(1744, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1745, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb'),
(1746, 'wqjkjkj', '7676.00', '767.00', 'jnkjnkjnkj'),
(1747, 'yyutyu', '6565.00', '54654.00', ''),
(1748, 'Viper Blade Grade II', '325.50', '410.76', 'This is a super fine viper blades from Bosch for all Ford cars.'),
(1749, 'wqdqwd', '656.00', '65656.00', 'hjjhbhbjhb');

-- --------------------------------------------------------

--
-- Table structure for table `parts_stock`
--

CREATE TABLE IF NOT EXISTS `parts_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `parts_stock`
--

INSERT INTO `parts_stock` (`id`, `part_id`, `quantity`) VALUES
(1, 1001, 100),
(2, 1003, 15),
(3, 1004, 0),
(4, 1005, 788),
(5, 10004, 1),
(6, 1013, 10);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET latin1 NOT NULL,
  `role` int(11) NOT NULL,
  `address` text CHARACTER SET latin1 NOT NULL,
  `contact` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(200) CHARACTER SET latin1 NOT NULL,
  `notes` text CHARACTER SET latin1 NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `role`, `address`, `contact`, `email`, `notes`, `created_on`) VALUES
(1, 'Shafi', 1, 'Angadippuram,\r\nMalappuram', '98765467', 'shafi@test.com', 'kjhuyuh asdasdas dasd asd adasdasdqwdq qdqwdqwdqwd.', '2013-08-14'),
(2, 'Nisar', 2, '0', '2324234', '', '', '0000-00-00'),
(5, 'TesterEdit', 1, '0', '123123', 'niaa@Aasa.sa', 'hytrtdyt', '2013-08-15');

-- --------------------------------------------------------

--
-- Table structure for table `staff_roles`
--

CREATE TABLE IF NOT EXISTS `staff_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `staff_roles`
--

INSERT INTO `staff_roles` (`id`, `role`) VALUES
(1, 'Mechanic'),
(2, 'Painter');

-- --------------------------------------------------------

--
-- Table structure for table `wages`
--

CREATE TABLE IF NOT EXISTS `wages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `staff` int(11) NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `wages`
--

INSERT INTO `wages` (`id`, `amount`, `staff`, `description`, `created_on`) VALUES
(2, '1750.50', 2, 'hihiuhihih', '2013-08-02'),
(3, '2000.90', 1, 'knuhiuhiuhhuihihihi', '2013-08-25');
